
import java.io.*;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.*;
import javax.servlet.*;
    import javax.servlet.*;
 
    @WebServlet("/register")
public class register extends HttpServlet
{
	  protected void doGet(HttpServletRequest request, HttpServletResponse   response) throws ServletException, IOException {
			
	
	
		
		  response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
		String id=request.getParameter("username");
		String name=request.getParameter("password");
		
	
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			 String url="jdbc:mysql://localhost:3306/db";
				 String uname="root";
				 String password="root";
			 Connection con=DriverManager.getConnection(url,uname,password);
			 
		
				
				PreparedStatement st=con.prepareStatement("insert into register values(?,?)");
				st.setString(1, id);
				st.setString(2, name);
				
				  int rs=st.executeUpdate();
				 if(rs!=0)
				 {
					  
					  out.print("<html>");
						out.print("<head>");
							out.print("<meta charset=\"utf-8\">");
							out.print("<title>Admin Login Form</title>");
							out.print("<link rel=\"stylesheet\" href=\"style.css\">");
						out.print("</head>");
					out.print("<body>");	
						
					       out.print(" <div class=\"menuBox\">"); 
								out.print("<h1>You have been successfully signed up.</h1>");
								out.print("<h1><a href=\"user.html\">Click here</a> to login</h1>");
							out.print("</div>");
							
					out.print("</body>");	
				out.print("</html>");	

				
				 }  	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.close();
		// 
		
		}
		 
	}
	
	
	




	




